import { useState } from "react"
import axios from "axios"

const API_URL = "http://localhost:8000"

export default function App() {
  const [file, setFile] = useState(null)
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)
  const [dragOver, setDragOver] = useState(false)

  const handleFileChange = (e) => {
    setFile(e.target.files[0])
    setResult(null)
    setError(null)
  }

  const handleDrop = (e) => {
    e.preventDefault()
    setDragOver(false)
    const dropped = e.dataTransfer.files[0]
    if (dropped) {
      setFile(dropped)
      setResult(null)
      setError(null)
    }
  }

  const handleAnalyze = async () => {
    if (!file) return
    setLoading(true)
    setError(null)
    setResult(null)

    const formData = new FormData()
    formData.append("file", file)

    try {
      const response = await axios.post(`${API_URL}/analyze`, formData, {
        headers: { "Content-Type": "multipart/form-data" }
      })
      setResult(response.data)
    } catch (err) {
      setError(err.response?.data?.detail || "Something went wrong. Is the API running?")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-950 text-white">

      {/* HEADER */}
      <div className="bg-gray-900 border-b border-gray-800 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="text-2xl">🏏</span>
          <div>
            <h1 className="text-xl font-semibold text-white">NeuroCoach</h1>
            <p className="text-xs text-gray-400">AI Cricket Player Analysis</p>
          </div>
        </div>
        <span className="text-xs bg-green-900 text-green-300 px-3 py-1 rounded-full">
          API Live
        </span>
      </div>

      <div className="max-w-5xl mx-auto px-6 py-10">

        {/* UPLOAD SECTION */}
        <div
          className={`border-2 border-dashed rounded-2xl p-12 text-center transition-all cursor-pointer mb-8
            ${dragOver ? "border-blue-400 bg-blue-950" : "border-gray-700 bg-gray-900 hover:border-gray-500"}`}
          onDragOver={(e) => { e.preventDefault(); setDragOver(true) }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
          onClick={() => document.getElementById("fileInput").click()}
        >
          <input
            id="fileInput"
            type="file"
            accept=".mp4,.avi,.mov"
            className="hidden"
            onChange={handleFileChange}
          />
          <div className="text-5xl mb-4">🎬</div>
          {file ? (
            <div>
              <p className="text-green-400 font-medium text-lg">✅ {file.name}</p>
              <p className="text-gray-400 text-sm mt-1">{(file.size / 1024 / 1024).toFixed(1)} MB — ready to analyze</p>
            </div>
          ) : (
            <div>
              <p className="text-gray-300 text-lg font-medium">Drop your cricket video here</p>
              <p className="text-gray-500 text-sm mt-2">or click to browse — .mp4, .avi, .mov supported</p>
            </div>
          )}
        </div>

        {/* ANALYZE BUTTON */}
        <button
          onClick={handleAnalyze}
          disabled={!file || loading}
          className={`w-full py-4 rounded-xl font-semibold text-lg transition-all mb-8
            ${!file || loading
              ? "bg-gray-800 text-gray-500 cursor-not-allowed"
              : "bg-blue-600 hover:bg-blue-500 text-white cursor-pointer"
            }`}
        >
          {loading ? "🔍 Analyzing match footage... (2-3 mins)" : "⚡ Analyze Video"}
        </button>

        {/* ERROR */}
        {error && (
          <div className="bg-red-950 border border-red-800 rounded-xl p-4 mb-8 text-red-300 text-sm">
            ❌ {error}
          </div>
        )}

        {/* LOADING STATE */}
        {loading && (
          <div className="bg-gray-900 border border-gray-800 rounded-2xl p-8 text-center mb-8">
            <div className="text-4xl mb-4 animate-bounce">🏏</div>
            <p className="text-gray-300 font-medium">Running YOLOv8 player tracking...</p>
            <p className="text-gray-500 text-sm mt-2">Detecting players · Building heatmap · Calculating stats</p>
            <div className="mt-6 bg-gray-800 rounded-full h-2 overflow-hidden">
              <div className="bg-blue-500 h-2 rounded-full animate-pulse w-3/4"></div>
            </div>
          </div>
        )}

        {/* RESULTS */}
        {result && (
          <div className="space-y-6">

            {/* SUMMARY CARDS */}
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-gray-900 border border-gray-800 rounded-xl p-5 text-center">
                <div className="text-3xl font-semibold text-blue-400">{result.total_frames}</div>
                <div className="text-gray-400 text-sm mt-1">Frames Processed</div>
              </div>
              <div className="bg-gray-900 border border-gray-800 rounded-xl p-5 text-center">
                <div className="text-3xl font-semibold text-green-400">{result.real_players_detected}</div>
                <div className="text-gray-400 text-sm mt-1">Players Detected</div>
              </div>
              <div className="bg-gray-900 border border-gray-800 rounded-xl p-5 text-center">
                <div className="text-3xl font-semibold text-purple-400">Player {result.best_tracked_player}</div>
                <div className="text-gray-400 text-sm mt-1">Best Tracked</div>
              </div>
            </div>

            {/* HEATMAP */}
            <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6">
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                🗺️ Movement Heatmap
                <span className="text-xs text-gray-500 font-normal">Player {result.best_tracked_player}</span>
              </h2>
              <img
                src={`${API_URL}${result.heatmap_url}`}
                alt="Player Heatmap"
                className="w-full rounded-xl border border-gray-700"
              />
            </div>

            {/* PLAYER STATS TABLE */}
            <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6">
              <h2 className="text-lg font-semibold mb-4">📊 Player Statistics</h2>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-gray-800 text-gray-400 text-left">
                      <th className="pb-3 pr-6">Player</th>
                      <th className="pb-3 pr-6">Frames Tracked</th>
                      <th className="pb-3 pr-6">Field Coverage</th>
                      <th className="pb-3 pr-6">Avg Position</th>
                      <th className="pb-3">Presence</th>
                    </tr>
                  </thead>
                  <tbody>
                    {result.player_stats.map((player, index) => (
                      <tr key={player.player_id} className="border-b border-gray-800/50 hover:bg-gray-800/30 transition-colors">
                        <td className="py-3 pr-6">
                          <div className="flex items-center gap-2">
                            <span className={`w-2 h-2 rounded-full ${index === 0 ? "bg-blue-400" : "bg-gray-600"}`}></span>
                            <span className="font-medium">Player {player.player_id}</span>
                            {index === 0 && <span className="text-xs bg-blue-900 text-blue-300 px-2 py-0.5 rounded-full">Top</span>}
                          </div>
                        </td>
                        <td className="py-3 pr-6 text-gray-300">{player.frames_tracked}</td>
                        <td className="py-3 pr-6">
                          <div className="flex items-center gap-2">
                            <div className="w-24 bg-gray-800 rounded-full h-1.5">
                              <div
                                className="bg-green-500 h-1.5 rounded-full"
                                style={{ width: `${Math.min(player.coverage_percent * 4, 100)}%` }}
                              ></div>
                            </div>
                            <span className="text-gray-300">{player.coverage_percent}%</span>
                          </div>
                        </td>
                        <td className="py-3 pr-6 text-gray-400 text-xs">
                          x: {player.avg_x_position}, y: {player.avg_y_position}
                        </td>
                        <td className="py-3">
                          <div className="w-24 bg-gray-800 rounded-full h-1.5">
                            <div
                              className="bg-blue-500 h-1.5 rounded-full"
                              style={{ width: `${(player.frames_tracked / result.total_frames) * 100}%` }}
                            ></div>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}
      </div>
    </div>
  )
}